# Preliminary campaign measurements

Finalized 600 / 600 planned episodes; 60 distinct suite/task pairs.

Rates retain raw counts. Error outcomes are unknown, and unexposed attacks do not demonstrate resistance.

Unknown clean episodes: 5. Attack episodes paired to clean controls: verified true 232, verified false 228, unknown outcome 20, missing result 0. These counts partition attacks; attack variants reuse clean controls. An unknown clean outcome does not establish inability.

| Outcome | Successes / denominator | Rate | 95% interval |
|---|---:|---:|---:|
| clean_utility_all_attempts | 58 / 120 | 48.3% | 35.8% – 59.2% |
| clean_utility_known | 58 / 115 | 50.4% | 38.6% – 62.6% |
| attack_utility_all_attempts | 173 / 480 | 36.0% | 26.7% – 45.8% |
| attack_utility_known | 173 / 458 | 37.8% | 28.0% – 47.6% |
| attack_success_all_attempts | 92 / 480 | 19.2% | 15.0% – 23.5% |
| attack_success_known | 92 / 458 | 20.1% | 15.5% – 25.0% |
| attack_success_clean_completable_all_attempts | 55 / 232 | 23.7% | 17.3% – 30.0% |
| attack_success_clean_completable_known | 55 / 230 | 23.9% | 17.4% – 30.4% |
| attack_exposure | 412 / 480 | 85.8% | 76.7% – 94.2% |
| attack_success_exposed_all_attempts | 92 / 412 | 22.3% | 17.9% – 26.9% |
| attack_success_exposed_known | 92 / 390 | 23.6% | 18.7% – 28.7% |
| attack_success_exposed_clean_completable_known | 55 / 226 | 24.3% | 17.8% – 30.9% |

Intervals reflect variation over the selected tasks. Repeated episodes remain in task clusters; fixed cohort selection and a single host limit generalization.

Known repeat comparisons require at least two completed Boolean outcomes per cell. One known outcome plus unknowns, or all unknowns, does not establish agreement. Legacy raw disagreement counts also include null-versus-Boolean changes.

| Repeated outcome | Comparable / repeated cells | Known agreement / disagreement | All-known / partial-unknown / all-unknown | Comparable partial-unknown |
|---|---:|---:|---:|---:|
| Utility | 280 / 300 | 254 / 26 | 280 / 13 / 7 | 0 |
| Attack success (attack cells only) | 224 / 240 | 214 / 10 | 224 / 10 / 6 | 0 |

| Condition | Latency median / p95 (s) | Prompt / completion tokens (mean) | Native decode tokens/s (median) |
|---|---:|---:|---:|
| clean | 52.64 / 185.60 | 16795.91 / 235.67 | 15.21 |
| attack | 53.78 / 185.22 | 18960.17 / 242.21 | 15.44 |

Errors by type: `{"APITimeoutError": 20, "EpisodeTimeoutError": 1, "ToolStepLimitError": 6}`.
Reviewed episodes: 168; refusal keyword candidates: 12. Candidates have no semantic label until reviewed.
Clean refusal review: 120 / 120 finalized clean episodes reviewed; unnecessary refusals 2, indeterminate 13. Possible incidence among reviewed clean episodes: 1.7% – 12.5% (classification bounds, not a confidence interval). Unreviewed finalized clean episodes: 0; pending episodes have no inferred refusal label.
Selected-trace review gate: 30 / 30 reviewed; complete=True. Selection remains provisional until collection finishes.

Server RSS is sampled process resident memory, not total GPU allocation or machine unified memory. Native decode throughput excludes prefill; completion tokens / response seconds includes request overhead and prefill. Startup observations are separate from warmed episode latency.

Artifacts: `summary.json`, `episodes.csv`, `review.csv`, `review-sample.csv`, `requests.csv`, `latency.svg`. See `docs/metrics.md` for definitions and review instructions.

Possible ASR bounds under unknown outcomes (these are not confidence intervals):

| Metric | Unknown outcomes | Lower / upper possible rate |
|---|---:|---:|
| attack_success_all_attempts | 22 | 19.2% / 23.8% |
| attack_success_clean_completable_all_attempts | 2 | 23.7% / 24.6% |
| attack_success_exposed_all_attempts | 22 | 22.3% / 27.7% |
