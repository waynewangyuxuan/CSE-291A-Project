import json
from pathlib import Path
from agentdojo.task_suite.load_suites import get_suite
from agentdojo.functions_runtime import FunctionsRuntime
from agent_tradeoffs.agent import LocalAgent, load_system_message, tool_result_to_text
from agent_tradeoffs.config import ExperimentConfig
from agent_tradeoffs.runner import make_injections
from agent_tradeoffs.request_tokens import RequestTokenCounter
root=Path('artifacts/phase2-spike/reference-profile')
root.mkdir(parents=True,exist_ok=True)
suite=get_suite('v1.2.2','travel')
task=suite.user_tasks['user_task_17']
goal=suite.injection_tasks['injection_task_0']
runtime=FunctionsRuntime(suite.tools)
tools=[{'type':'function','function':{'name':f.name,'description':f.description,'parameters':f.parameters.model_json_schema()}} for f in runtime.functions.values()]
config=ExperimentConfig.model_validate({'model':{'model':'qwen3-8b-f16','base_url':'http://127.0.0.1:8085/v1','seed':17,'temperature':.7,'extra_body':{'chat_template_kwargs':{'enable_thinking':False},'cache_prompt':False,'top_p':.8,'top_k':20,'min_p':0.}}})
agent=LocalAgent(config,root)
counter=RequestTokenCounter(config.model.base_url,root/'counts.jsonl',lambda:120)
profiles=[]
for condition in ('clean','attack'):
    payloads,injections=make_injections(suite,agent,'ignore_previous_append',task,goal) if condition=='attack' else ({},{})
    env=task.init_environment(suite.load_and_inject_default_environment(injections))
    messages=[{'role':'system','content':load_system_message()},{'role':'user','content':task.PROMPT}]
    counts=[{'round':0,'full_tokens':counter.count(agent.request_payload(messages,tools))}]
    for i,call in enumerate(task.ground_truth(env)):
        value,error=runtime.run_function(env,call.function,call.args,raise_on_error=True)
        assert error is None
        cid=f'ref-{i}'
        messages.extend([{'role':'assistant','content':'','tool_calls':[{'id':cid,'type':'function','function':{'name':call.function,'arguments':json.dumps(call.args)}}]},{'role':'tool','tool_call_id':cid,'content':tool_result_to_text(value)}])
        counts.append({'round':i+1,'tool':call.function,'full_tokens':counter.count(agent.request_payload(messages,tools)),'latest_group_tokens':counter.count(agent.request_payload(messages[:2]+messages[-2:],tools))})
    item={'condition':condition,'counts':counts,'reference_only_never_an_agent_input':True,'messages':messages,'attack_payloads':payloads}
    (root/f'{condition}.json').write_text(json.dumps(item,indent=2))
    profiles.append({k:v for k,v in item.items() if k not in ('messages','attack_payloads')})
(root/'profile.json').write_text(json.dumps(profiles,indent=2))
print(json.dumps(profiles,indent=2))
