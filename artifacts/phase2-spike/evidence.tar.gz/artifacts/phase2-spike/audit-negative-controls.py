import gzip,hashlib,json,shutil,sys,tempfile
from pathlib import Path
sys.path.insert(0,'scripts')
from audit_phase2_spike import verify_episode
from agent_tradeoffs.config import ExperimentConfig
plan=json.loads(Path('configs/phase2-spike/plan.json').read_text())
entry=plan['runs'][0]
config=ExperimentConfig.model_validate(entry['config'])
run=config.runner.output_root/entry['run_id']
manifest=json.loads((run/'manifest.json').read_text())
source=run/'episodes/user_task_17__clean'
checks=[]
for mutation,expected in [('source_ids','Retained source IDs differ'),('cost','Agent cost accounting differs'),('shadow','Uncompressed evidence shadows')]:
 with tempfile.TemporaryDirectory(prefix='phase2-audit-') as scratch:
  directory=Path(scratch)/'episode';shutil.copytree(source,directory)
  if mutation=='source_ids':
   trace=json.loads(gzip.decompress((directory/'trace.json.gz').read_bytes()))
   trace['context_memory']['events'][1]['retained_source_message_ids']=[0,1,3]
   data=json.dumps(trace).encode();packed=gzip.compress(data,mtime=0)
   (directory/'trace.json.gz').write_bytes(packed)
   compression=json.loads((directory/'compression.json').read_text())
   for item in compression['artifacts']:
    if item['path']=='trace.json.gz':
     item['compressed_sha256']=hashlib.sha256(packed).hexdigest();item['original_sha256']=hashlib.sha256(data).hexdigest()
   (directory/'compression.json').write_text(json.dumps(compression))
  elif mutation=='cost':
   result=json.loads((directory/'result.json').read_text());result['usage']['prompt_tokens']+=1
   (directory/'result.json').write_text(json.dumps(result))
  else:(directory/'trace.json').write_text('{}')
  try:verify_episode(directory,config,manifest)
  except ValueError as error:
   assert expected in str(error),(expected,str(error));checks.append({'mutation':mutation,'rejected':True,'reason':str(error)})
  else:raise AssertionError(f'Accepted {mutation}')
Path('artifacts/phase2-spike/audit-negative-controls.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
