import json, sys
from copy import deepcopy
from pathlib import Path
sys.path.insert(0,'scripts')
from phase2_budget_spike import experiment
from agentdojo.functions_runtime import FunctionsRuntime
from agentdojo.task_suite.load_suites import get_suite
from agent_tradeoffs.agent import LocalAgent
from agent_tradeoffs.memory import ContextBudgetExceededError
from agent_tradeoffs.reporting import atomic_json
root=Path('artifacts/phase2-spike/memory-proof')
root.mkdir(parents=True,exist_ok=True)
source=json.loads(Path('artifacts/phase2-spike/reference-profile/attack.json').read_text())['messages']
# Repeat observed development tool groups solely to exercise a second rolling update.
# This is a context integration test, never a benchmark episode or scored model input.
transcript=deepcopy(source)
extra=deepcopy(source[2:])
for i in range(0,len(extra),2):
    cid=f'replay-{i}'
    extra[i]['tool_calls'][0]['id']=cid
    extra[i+1]['tool_call_id']=cid
transcript+=extra
runtime=FunctionsRuntime(get_suite('v1.2.2','travel').tools)
tools=[{'type':'function','function':{'name':f.name,'description':f.description,'parameters':f.parameters.model_json_schema()}} for f in runtime.functions.values()]
results=[]
for policy in ('full','truncate','summary'):
    directory=root/policy
    directory.mkdir(exist_ok=True)
    agent=LocalAgent(experiment('f16',policy),directory)
    overflow=None
    for end in range(2,len(transcript)+1,2):
        try:
            view=agent.memory.prepare(transcript[:end],measure=lambda view:agent.counter.count(agent.request_payload(view,tools)),output_tokens=2048)
        except ContextBudgetExceededError as error:
            overflow={'end':end,'error':str(error)}
            break
    metrics=agent.memory.metrics()
    atomic_json(directory/'proof.json',{'kind':'synthetic_repeated_development_history_not_evaluation','events':metrics,'overflow':overflow})
    if policy=='full': assert overflow is not None
    else: assert overflow is None
    if policy=='summary': assert metrics['compactions']>=2
    results.append({'policy':policy,'compactions':metrics['compactions'],'overflow':overflow,'summary_tokens':metrics['summary_usage']})
    print(json.dumps(results[-1]),flush=True)
atomic_json(root/'proof.json',results)
