"""Package the finalized development spike; verify every archived member."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path.cwd()
output = root / 'artifacts/phase2-spike'
archive = output / 'evidence.tar.gz'
inventory = output / 'manifest.json'
state = json.loads((root / 'artifacts/phase2-budget-spike-v1/campaign.json').read_text())
audit = json.loads((root / 'results/phase2-spike/verification.json').read_text())
assert state['status'] == 'completed'
assert audit['episodes_checked'] == audit['expected_episodes'] == 18
assert audit['checks'] == 'passed' and not audit['partial']
paths = set()
for directory in ('artifacts/phase2-budget-spike-v1', 'artifacts/phase2-spike', 'configs/phase2-spike', 'results/phase2-spike'):
    for path in (root / directory).rglob('*'):
        if path.is_file() and not path.is_symlink() and not path.name.startswith('.') and path not in (archive, inventory) and path.name not in ('partial-audit.json',):
            paths.add(path)
paths.update((root / 'src/agent_tradeoffs').glob('*.py'))
for name in ('README.md', 'Makefile', 'pyproject.toml', 'uv.lock', 'scripts/phase2_budget_spike.py', 'scripts/audit_phase2_spike.py', 'scripts/prepare-q4.py', 'scripts/prepare-f16.py', 'scripts/bootstrap-runtime.sh', 'configs/runtime-qwen3-8b-f16.toml', 'docs/phase2-batches.md'):
    paths.add(root / name)
for directory in ('qwen3-8b-f16', 'qwen3-8b-derived-q8', 'qwen3-8b-derived-q4'):
    paths.update((root / '.cache/models' / directory).glob('*.provenance.json'))
    paths.update((root / '.cache/models' / directory).glob('*.manifest.json'))
rows = []
with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
    for path in sorted(paths):
        name = str(path.relative_to(root))
        data = path.read_bytes()
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(data))
        rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {row['path'] for row in rows}
    for row in rows:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
record = {'kind': 'development_spike_evidence_not_formal_evaluation', 'episodes': 18, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size, 'members': rows, 'verified': True}
inventory.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'members'}))
