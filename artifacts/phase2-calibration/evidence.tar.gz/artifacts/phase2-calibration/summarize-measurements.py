"""Derive development accounting from the reviewed, finalized cohorts."""

import hashlib
import json
from pathlib import Path

rows = []
for suffix, budget in (("", 7680), ("-tight", 7168), ("-before-action", 7040)):
    path = Path(f"results/phase2-calibration/verification{suffix}.json")
    audit = json.loads(path.read_text())
    assert audit["checks"] == "passed" and not audit["partial"]
    episodes = audit["episodes"]
    root = Path(f"artifacts/phase2-calibration{suffix}")
    memory = [json.loads(p.read_text()) for p in root.glob("runs/*/deployment-memory.json")]
    rows.append({
        "total_budget": budget,
        "input_allowance": budget - 2048,
        "audit": str(path),
        "audit_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "episodes": len(episodes),
        "completed": sum(e["status"] == "completed" for e in episodes),
        "errors": sum(e["status"] == "error" for e in episodes),
        "official_utility": {str(v): sum(e["utility"] is v for e in episodes) for v in (True, False, None)},
        "attacked_official_outcomes": {str(v): sum(e["condition"] == "attack" and e["attack_success"] is v for e in episodes) for v in (True, False, None)},
        "agent_requests": sum(e["requests"] for e in episodes),
        "compactions": sum(e["compactions"] for e in episodes),
        "episode_seconds": sum(e["duration_seconds"] for e in episodes),
        "campaign_seconds": json.loads((root / "campaign.json").read_text())["elapsed_seconds"],
        "agent_usage": {k: sum(e["agent_usage"][k] for e in episodes) for k in ("prompt_tokens", "completion_tokens", "total_tokens")},
        "summary_usage": {k: sum(e["summary_usage"][k] for e in episodes) for k in ("prompt_tokens", "completion_tokens", "total_tokens")},
        "run_peak_aggregate_rss_bytes_min": min(m["peak_rss_bytes"] for m in memory),
        "run_peak_aggregate_rss_bytes_max": max(m["peak_rss_bytes"] for m in memory),
    })
result = {
    "kind": "development_collection_accounting_not_population_rates",
    "scope": "All finalized episodes, including errors. Episode time includes live summaries and tokenization, excludes service startup; campaign time includes orchestration. RSS sums two resident model services plus orchestrator and can double-count shared pages. Standalone replay calls are separate from episodes.",
    "cohorts": rows,
}
Path("results/phase2-calibration/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
for row in rows:
    print(row["total_budget"], round(row["episode_seconds"], 1), row["agent_usage"]["total_tokens"], row["summary_usage"]["total_tokens"], [round(row[k] / 2**30, 2) for k in ("run_peak_aggregate_rss_bytes_min", "run_peak_aggregate_rss_bytes_max")])
