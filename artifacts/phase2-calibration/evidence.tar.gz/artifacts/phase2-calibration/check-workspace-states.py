"""Evaluate recorded Workspace34 states separately from official episode status."""
import gzip
import hashlib
import inspect
import json
from pathlib import Path
from agentdojo.task_suite.load_suites import get_suite

suite = get_suite('v1.2.2', 'workspace')
environment_type = type(suite.load_and_inject_default_environment({}))
rows = []
for cohort in ['phase2-calibration', 'phase2-calibration-tight', 'phase2-calibration-before-action']:
    for path in sorted((Path('artifacts') / cohort / 'runs').glob('*/episodes/*/result.json')):
        if 'workspace34' not in str(path):
            continue
        result = json.loads(path.read_text())
        raw = gzip.decompress((path.parent / 'trace.json.gz').read_bytes())
        trace = json.loads(raw)
        pre = environment_type.model_validate(trace['initial_environment'])
        post = environment_type.model_validate(trace['final_environment'])
        exact = pre.model_dump(mode='json') == trace['initial_environment'] and post.model_dump(mode='json') == trace['final_environment']
        rows.append({
            'cohort': cohort, 'run': path.parents[2].name,
            'episode_id': result['episode_id'], 'identity': result['identity'],
            'trace_sha256': hashlib.sha256(raw).hexdigest(),
            'status': result['status'], 'official_utility': result['utility'],
            'official_attack_success': result['attack_success'],
            'roundtrip_exact': exact,
            'state_only_utility_with_empty_answer': suite.user_tasks['user_task_34'].utility('', pre, post) if exact else None,
            'state_only_attack_success_with_empty_answer': suite.injection_tasks['injection_task_0'].security('', pre, post) if exact and result['condition'] == 'attack' else None,
        })
report = {
    'kind': 'secondary_observable_state_diagnostic_not_an_official_score_rewrite',
    'scope': 'Workspace34 and injection goal0 have source-inspected state-only checks. Empty final text is deliberately supplied. No inference or tool mutation occurs. Rehydration must reproduce both snapshots exactly before any derived score is accepted.',
    'interpretation': 'A task-changing action can succeed before a later context-budget error. A false attacker-goal check during an incomplete/incapable episode is not evidence of model resistance. Keep episode completion, observable actions, exposure and clean capability separate.',
    'checker_source_sha256': hashlib.sha256((inspect.getsource(type(suite.user_tasks['user_task_34'])) + inspect.getsource(type(suite.injection_tasks['injection_task_0']))).encode()).hexdigest(),
    'episodes': rows,
}
Path('results/phase2-calibration/state-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'states_checked': len(rows), 'exact_roundtrips': sum(r['roundtrip_exact'] for r in rows), 'incomplete_but_goal_achieved': sum(r['status'] == 'error' and r['state_only_utility_with_empty_answer'] is True for r in rows)}))
