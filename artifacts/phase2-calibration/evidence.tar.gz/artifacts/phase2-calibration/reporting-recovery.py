"""Record the reporting-only driver correction; preserve the interrupted state."""
import hashlib
import json
from pathlib import Path
from agent_tradeoffs.runner import implementation_identity
from agent_tradeoffs.reporting import atomic_json

root = Path('artifacts/phase2-calibration')
state_path = root / 'campaign.json'
state = json.loads(state_path.read_text())
old_driver = (root / 'driver-before-reporting-fix.py').read_bytes()
new_driver = Path('scripts/phase2_calibration.py').read_bytes()
expected = old_driver.replace(b'                        "error",\n', b'').replace(
    b'                "compactions": result["context_memory"]["compactions"],',
    b'                "error": result.get("error"),\n                "compactions": result["context_memory"]["compactions"],'
)
assert new_driver == expected, 'Correction must change only optional error rendering'
assert state['identity']['implementation'] == implementation_identity()
assert state['status'] == 'interrupted' and state['error'] == "KeyError: 'error'"
assert state['identity']['driver_sha256'] == hashlib.sha256(old_driver).hexdigest()
archive = root / 'campaign-before-reporting-fix.json'
assert not archive.exists(), 'Recovery already recorded'
archive.write_bytes(state_path.read_bytes())
results = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'runs').glob('*/episodes/*/result.json')}
assert len(results) == 2
record = {
    'reason': 'Status rendering required an absent optional error field after the first pair finalized. No inference/configuration change.',
    'old_campaign_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'old_driver_sha256': state['identity']['driver_sha256'],
    'new_driver_sha256': hashlib.sha256(new_driver).hexdigest(),
    'preserved_results': results,
    'resume': 'Existing run manifests retain their original implementation/config/runtime identities; finalized pair is skipped. Budget elapsed time is carried forward.'
}
state['identity']['driver_sha256'] = record['new_driver_sha256']
state['reporting_recovery'] = record
atomic_json(root / 'reporting-recovery.json', record)
atomic_json(state_path, state)
print('Recorded reporting-only recovery; preserved 2 finalized episodes')
