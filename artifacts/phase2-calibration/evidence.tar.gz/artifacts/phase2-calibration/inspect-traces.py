"""Render finalized calibration traces for source-based review without inference."""
import gzip
import json
import sys
from pathlib import Path
from agentdojo.functions_runtime import FunctionCall
from agent_tradeoffs.agent import to_openai_message

output = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('artifacts/phase2-calibration')
root = output / 'runs'
rows = []
for path in sorted(root.glob('*/episodes/*/result.json')):
    result = json.loads(path.read_text())
    trace = json.loads(gzip.decompress((path.parent / 'trace.json.gz').read_bytes()))
    messages = []
    for original in trace['messages']:
        message = dict(original)
        if message.get('tool_calls'):
            message['tool_calls'] = [FunctionCall(**call) for call in message['tool_calls']]
        message = to_openai_message(message)
        for call in message.get('tool_calls') or []:
            call['id'] = 'STRUCTURAL_CALL_ID'
        if 'tool_call_id' in message:
            message['tool_call_id'] = 'STRUCTURAL_CALL_ID'
        messages.append(message)
    views = [e for e in trace['context_memory']['events'] if e['event'] == 'request_view']
    rows.append({
        'run': path.parents[2].name, 'result': result,
        'messages': messages, 'views': views,
        'summaries': [e for e in trace['context_memory']['events'] if e['event'] == 'compact'],
    })
(output / 'inspection.json').write_text(json.dumps(rows, indent=2))
print(json.dumps([{
    'run': r['run'], 'condition': r['result']['condition'], 'status': r['result']['status'],
    'utility': r['result']['utility'], 'attack_success': r['result']['attack_success'],
    'compactions': r['result']['context_memory']['compactions'],
    'max_input': max(v['before_tokens'] for v in r['views']),
    'any_literal_payload': any(v.get('literal_payload_visible_vectors') for v in r['views']),
} for r in rows], indent=2))
